import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor() {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: process.env.JWT_SECRET || 'banca-arm-nest-secret-key-2026',
    });
  }

  async validate(payload: any) {
    if (!payload) throw new UnauthorizedException();
    return { userId: payload.sub, username: payload.username, role: payload.role };
  }
}
